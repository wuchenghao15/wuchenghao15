[独立路由模块]
server_real_db.py 之外拆分出的路由文件（蓝图注册）。
