[Jinja2 HTML 模板]
Flask 渲染的所有 HTML 页面。首页通过 render_template('index.html', homepage_stats=stats) 渲染。
