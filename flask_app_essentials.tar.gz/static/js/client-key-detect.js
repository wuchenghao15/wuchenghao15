/**
 * client-key-detect.js — 双硬件密钥(SZU100+VIKEY)自动检测器
 * ================================================================
 * 在所有 admin_app 页面通用加载, 5s 间隔轮询 /api/hardware/dual-status
 *   · 双钥 false→true: 触发 onDualKeyLogin 回调 (页面刷新后载入SA专有界面)
 *   · 双钥 true→false: 触发 onKeyRemoved 回调 (跳转首页)
 *   · 401 未登录: 静默跳过 (不干扰登录页)
 *   · 连续失败: 指数退避 5→10→20→40→60(max)
 *   · 成功一次: 立即重置 5s
 */
(function () {
  'use strict';
  var BASE_INTERVAL = 5000;
  var MAX_INTERVAL = 60000;
  var API = '/api/hardware/dual-status';

  var _pollTimer = null;
  var _currentInterval = BASE_INTERVAL;
  var _prevDual = false;
  var _config = {};

  function _fetch() {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', API, true);
    xhr.timeout = 8000;
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4) return;
      if (xhr.status === 401) {
        // 未登录, 静默跳过, 不退避
        _schedule(BASE_INTERVAL);
        return;
      }
      if (xhr.status === 200) {
        try {
          var data = JSON.parse(xhr.responseText || '{}');
          _handleSuccess(data);
        } catch (e) {
          _handleError();
        }
      } else {
        _handleError();
      }
    };
    xhr.ontimeout = function () { _handleError(); };
    xhr.onerror = function () { _handleError(); };
    xhr.send();
  }

  function _handleSuccess(data) {
    _currentInterval = BASE_INTERVAL; // 成功重置
    var both = data.both_authenticated === true;
    var isSa = data.is_sa === true;

    if (both && !_prevDual) {
      // false→true: 双钥插入成功
      _prevDual = true;
      if (typeof _config.onDualKeyLogin === 'function') {
        try { _config.onDualKeyLogin(data); } catch (e) {}
      }
    } else if (!both && _prevDual) {
      // true→false: 双钥拔出
      _prevDual = false;
      if (typeof _config.onKeyRemoved === 'function') {
        try { _config.onKeyRemoved(data); } catch (e) {}
      }
    }
    // 非 SA 用户: both 永远 false, 不会触发 onDualKeyLogin
    _schedule(BASE_INTERVAL);
  }

  function _handleError() {
    _currentInterval = Math.min(_currentInterval * 2, MAX_INTERVAL);
    _schedule(_currentInterval);
  }

  function _schedule(delay) {
    if (_pollTimer) { clearTimeout(_pollTimer); _pollTimer = null; }
    _pollTimer = setTimeout(_fetch, delay);
  }

  var ClientKeyDetect = {
    startAutoPolling: function (config) {
      _config = config || {};
      _prevDual = false;
      _currentInterval = BASE_INTERVAL;
      // 首次立即检测 (不等待5s)
      _fetch();
    },
    stopAutoPolling: function () {
      if (_pollTimer) { clearTimeout(_pollTimer); _pollTimer = null; }
    },
    checkOnce: function (callback) {
      var xhr = new XMLHttpRequest();
      xhr.open('GET', API, true);
      xhr.timeout = 8000;
      xhr.onreadystatechange = function () {
        if (xhr.readyState !== 4) return;
        if (xhr.status === 200) {
          try { callback(JSON.parse(xhr.responseText || '{}')); }
          catch (e) { callback({ both_authenticated: false }); }
        } else {
          callback({ both_authenticated: false, status_code: xhr.status });
        }
      };
      xhr.ontimeout = function () { callback({ both_authenticated: false }); };
      xhr.onerror = function () { callback({ both_authenticated: false }); };
      xhr.send();
    }
  };

  window.ClientKeyDetect = ClientKeyDetect;
})();
