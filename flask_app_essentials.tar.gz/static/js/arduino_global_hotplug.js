/* ============================================================
 * Arduino 全局跨页面热插拔检测脚本 (T05a)
 * 2 秒轮询设备插入/拔出事件，跨页面保持行为一致
 * 无内联 style，无裸 BEM 双横线类名
 * ============================================================ */
(function () {
  'use strict';

  var POLL_MS = 2000;
  var EXCLUDE_PATHS = [/\/admin_app\/arduino_ide$/, /\/admin_app\/arduino_admin_setup$/];

  window.ARDUINO_GLOBAL = window.ARDUINO_GLOBAL || {};
  window.ARDUINO_GLOBAL.pendingInsert = false;

  function doInsertJump(vid_pid, model) {
    fetch('/auth/session_health', { credentials: 'include' })
      .then(function (r) { return r.json(); })
      .then(function (h) {
        if (!h.logged_in) {
          // v2.0: 直接跳 /login（HTML 页面），不经过 /index（会重定向到 /auth/login 返回 JSON）
          try { localStorage.setItem('ARDUINO_BOUND_VIDPID', vid_pid || ''); } catch (e) {}
          var qs = new URLSearchParams();
          qs.set('arduino_inserted', '1');
          if (vid_pid) qs.set('vid_pid', vid_pid);
          if (model) qs.set('model', encodeURIComponent(model));
          location.replace('/login?' + qs.toString());
          return;
        }
        fetch('/api/arduino/session/bind', { credentials: 'include' })
          .then(function (r) { return r.json(); })
          .then(function (d) {
            if (d.bound || (d.data && d.data.bound)) {
              fetch('/api/arduino/session/redirect_target', { credentials: 'include' })
                .then(function (r2) { return r2.json(); })
                .then(function (rd) {
                  var target = rd.redirect || (rd.data && rd.data.redirect);
                  if (target) location.replace(target);
                });
            }
          });
      });
  }

  function pollOnce() {
    fetch('/api/arduino/events/poll?global=1', { credentials: 'include' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        var events = d.events || (d.data && d.data.events) || [];
        for (var i = 0; i < events.length; i++) {
          var ev = events[i];
          var et = ev.event_type || (ev.payload && ev.payload.event_type);
          var vp = ev.device_vid_pid || (ev.payload && ev.payload.device_vid_pid);
          var model = ev.board_model || (ev.payload && ev.payload.board_model);
          var eid = ev.event_id || (ev.payload && ev.payload.event_id);
          if (et === 'insert') {
            // ack 事件以防止重复处理
            if (eid) {
              fetch('/api/arduino/events/ack', {
                method: 'POST', credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ event_id: eid })
              }).catch(function () {});
            }
            var current = location.pathname;
            if (EXCLUDE_PATHS.some(function (re) { return re.test(current); })) {
              continue;
            }
            // 单轮确认：引擎层 scan_devices 已通过 prev_connected 去重，
            // 收到 insert 事件直接跳转，无需前端二次确认
            doInsertJump(vp, model);
          } else if (et === 'remove') {
            if (eid) {
              fetch('/api/arduino/events/ack', {
                method: 'POST', credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ event_id: eid })
              }).catch(function () {});
            }
            try { localStorage.removeItem('ARDUINO_BOUND_VIDPID'); } catch (e) {}
            var cp = location.pathname;
            if (cp === '/admin_app/arduino_ide' || cp === '/admin_app/arduino_admin_setup') {
              window.dispatchEvent(new CustomEvent('arduino-device-removed', {
                detail: { reason: 'device_removed', vid_pid: vp, removed_at: Date.now() }
              }));
            }
          }
        }
      })
      .catch(function () {});
  }

  setInterval(pollOnce, POLL_MS);
  pollOnce();
})();
