/**
 * ============================================================================
 * MTSCOS 统一前端 API 客户端 (契约对齐版)
 * ============================================================================
 * §14 IRON_RULE · STEP_7_EXECUTE · 模块1 后端Blueprint P4
 * flow_id: flow_dev_pages_functions_complete_20260818_001
 * contract_version: 1.2.0 (对照 flask-app/app/contracts/contract.yaml)
 *
 * 设计目标(对齐 contract.yaml §1 全局响应Schema):
 *   1. 8字段统一响应解析: code/msg/data/trace_id/timestamp/severity/repair_suggestion/design_tokens
 *   2. 成功判定: code === "0" (字符串零,对照mt_exception_code_dict)
 *   3. 异常码字典对照: E_AUTH_401/E_AUTH_403/E_ROUTE_404/E_SRV_500等20条
 *   4. severity → Element Plus Design Token 颜色映射(info/warning/error/critical)
 *   5. trace_id 端到端贯穿(日志+审计+前端)
 *   6. 向后兼容旧格式 {success: true, data: {}} 自动检测
 *   7. 集成 CSRF 拦截器(mtscos_csrf.js)
 *   8. Toast 通知 + Element Plus 主题色适配
 *
 * 用法:
 *   // 成功调用
 *   MTSCOSApi.get('/api/health').then(data => console.log(data));
 *   // POST
 *   MTSCOSApi.post('/api/ai/memory/save', {content: '笔记', tags: ['学习']})
 *     .then(data => showToast('已保存'))
 *     .catch(err => {
 *       if (err instanceof MTSCOSApi.MtscosApiError) {
 *         console.error(err.code, err.msg, err.severity, err.repair_suggestion);
 *       }
 *     });
 *   // 分页查询
 *   MTSCOSApi.get('/api/log/list', { query: { page: 1, per_page: 20 } })
 *     .then(result => console.log(result.items, result.pagination));
 * ============================================================================
 */
(function (global) {
    'use strict';

    // ============ 契约对照常量 ============
    const CONTRACT_VERSION = '1.2.0';
    const DEFAULT_TIMEOUT = 30000; // 30s, 对齐 contract.yaml E_TIMEOUT

    // 全局响应8字段(对照 contract.yaml §1)
    const RESPONSE_FIELDS = Object.freeze({
        CODE: 'code',
        MSG: 'msg',
        DATA: 'data',
        TRACE_ID: 'trace_id',
        TIMESTAMP: 'timestamp',
        SEVERITY: 'severity',
        REPAIR_SUGGESTION: 'repair_suggestion',
        DESIGN_TOKENS: 'design_tokens'
    });

    // ============ 异常码字典对照(contract.yaml §3, mt_exception_code_dict 20条) ============
    const EXCEPTION_CODES = Object.freeze({
        E_AUTH_401:        { http: 401, severity: 'error',    title: '未登录或登录已过期',   repair: '请重新登录' },
        E_AUTH_403:        { http: 403, severity: 'critical', title: '权限不足，禁止访问',   repair: '联系管理员申请权限' },
        E_ROUTE_404:       { http: 404, severity: 'warning',  title: '页面/接口不存在',       repair: '检查URL或联系运维' },
        E_SRV_500:         { http: 500, severity: 'critical', title: '服务器内部错误',       repair: '查看服务器日志' },
        E_SRV_502:         { http: 502, severity: 'error',    title: '上游网关错误',          repair: '检查上游服务' },
        E_SRV_504:         { http: 504, severity: 'error',    title: '网关超时',              repair: '检查网络或重试' },
        E_MAINTENANCE:     { http: 503, severity: 'info',     title: '系统维护中',            repair: '请稍后再试' },
        E_TIMEOUT:         { http: 504, severity: 'error',    title: '请求处理超时',          repair: '优化查询或重试' },
        E_TOKEN_MISSING:   { http: 400, severity: 'warning',  title: 'CSRF Token缺失',       repair: '刷新页面重新获取Token' },
        E_TOKEN_BREACH:    { http: 403, severity: 'error',    title: 'CSRF Token不匹配',      repair: '清除Cookie重新登录' },
        E_PERM_GROUP:      { http: 403, severity: 'error',    title: '用户组别不匹配',        repair: '使用正确组别账号' },
        E_PERM_STATUS:     { http: 403, severity: 'error',    title: '账号被禁用',            repair: '联系管理员解禁' },
        E_PERM_ANOMALY:    { http: 403, severity: 'warning',  title: '账号存在异常标记',      repair: '联系安全组复核' },
        E_PERM_ILLEGAL:    { http: 403, severity: 'critical', title: 'VIKEY合法性校验失败',   repair: '插入VIKEY加密狗重试' },
        E_PERM_TIMESTAMP:  { http: 401, severity: 'warning',  title: '登录时间戳过期',        repair: '重新登录' },
        E_BP_FAIL:         { http: 500, severity: 'error',    title: '蓝图注册失败',          repair: '检查Blueprint导入' },
        E_DB_CONSTRAINT:   { http: 500, severity: 'error',    title: '数据库约束失败',        repair: '检查字段唯一性/外键' },
        E_DB_ENCRYPT:      { http: 500, severity: 'critical', title: '数据库字段加密失败',    repair: '检查加密密钥配置' },
        E_RATE_LIMIT:      { http: 429, severity: 'warning',  title: '请求频率超限',          repair: '稍后重试或降低频率' },
        E_ABI_VERSION:     { http: 500, severity: 'error',    title: '版本ABI不兼容',         repair: '升级前端版本' }
    });

    // ============ severity → Element Plus Design Token 颜色映射 ============
    // 对照 contract.yaml §1 design_tokens 字段 + 设计规范.md Element Plus变量
    const SEVERITY_TOKENS = Object.freeze({
        info:     { color: 'var(--el-color-info)',    bg: 'var(--el-color-info-light-9)',    icon: 'ℹ' },
        warning:  { color: 'var(--el-color-warning)', bg: 'var(--el-color-warning-light-9)', icon: '⚠' },
        error:    { color: 'var(--el-color-danger)',  bg: 'var(--el-color-danger-light-9)',  icon: '✕' },
        critical: { color: 'var(--el-color-error)',   bg: 'var(--el-color-error-light-9)',  icon: '✕' },
        success:  { color: 'var(--el-color-success)', bg: 'var(--el-color-success-light-9)', icon: '✓' }
    });

    // ============ 自定义错误类(承载8字段错误响应) ============
    class MtscosApiError extends Error {
        constructor(code, msg, opts) {
            opts = opts || {};
            super(msg || (EXCEPTION_CODES[code] ? EXCEPTION_CODES[code].title : code));
            this.name = 'MtscosApiError';
            this.code = code;                                  // E_AUTH_401等异常码
            this.severity = opts.severity || 'error';          // info/warning/error/critical
            this.repair_suggestion = opts.repair_suggestion || '';
            this.design_tokens = opts.design_tokens || null;
            this.trace_id = opts.trace_id || '';               // 请求追踪ID
            this.http_status = opts.http_status || 500;          // HTTP状态码
            this.data = opts.data || null;                     // 失败时一般为null
            this.timestamp = opts.timestamp || '';
            this.route_path = opts.route_path || '';
            this.blueprint = opts.blueprint || '';
        }

        /** 渲染Toast用的颜色Token */
        getDesignTokens() {
            return SEVERITY_TOKENS[this.severity] || SEVERITY_TOKENS.error;
        }

        /** 是否为认证类错误(可触发跳转登录) */
        isAuthError() {
            return ['E_AUTH_401', 'E_PERM_TIMESTAMP', 'E_TOKEN_BREACH'].includes(this.code);
        }

        /** 是否为CSRF相关错误(可触发Token刷新) */
        isCSRFError() {
            return ['E_TOKEN_MISSING', 'E_TOKEN_BREACH'].includes(this.code);
        }

        /** 是否为权限不足 */
        isPermissionDenied() {
            return ['E_AUTH_403', 'E_PERM_GROUP', 'E_PERM_STATUS', 'E_PERM_ANOMALY', 'E_PERM_ILLEGAL'].includes(this.code);
        }

        toJSON() {
            return {
                name: this.name, code: this.code, msg: this.message,
                severity: this.severity, repair_suggestion: this.repair_suggestion,
                design_tokens: this.design_tokens, trace_id: this.trace_id,
                http_status: this.http_status, timestamp: this.timestamp,
                route_path: this.route_path, blueprint: this.blueprint
            };
        }
    }

    // ============ Toast 通知容器(惰性创建) ============
    let _toastContainer = null;

    function _ensureToastContainer() {
        if (_toastContainer) return _toastContainer;
        if (typeof document === 'undefined') return null;
        _toastContainer = document.createElement('div');
        _toastContainer.id = 'mtscos-api-toast-container';
        _toastContainer.style.cssText =
            'position:fixed;top:20px;right:20px;z-index:99999;display:flex;flex-direction:column;gap:10px;pointer-events:none;';
        document.body.appendChild(_toastContainer);
        // 注入动画样式
        if (!document.getElementById('mtscos-toast-style')) {
            const s = document.createElement('style');
            s.id = 'mtscos-toast-style';
            s.textContent =
                '@keyframes mtscos-slide-in { from { transform: translateX(120%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }' +
                '@keyframes mtscos-slide-out { from { transform: translateX(0); opacity: 1; } to { transform: translateX(120%); opacity: 0; } }';
            document.head.appendChild(s);
        }
        return _toastContainer;
    }

    /**
     * 显示Toast通知(对齐severity颜色Token)
     * @param {string} message - 消息内容
     * @param {string} severity - info/warning/error/critical/success
     * @param {number} duration - 持续毫秒
     */
    function showToast(message, severity, duration) {
        severity = severity || 'info';
        duration = duration || 3000;
        const container = _ensureToastContainer();
        if (!container) return;
        const tokens = SEVERITY_TOKENS[severity] || SEVERITY_TOKENS.info;
        const toast = document.createElement('div');
        toast.style.cssText =
            'background:' + tokens.bg + ';' +
            'color:' + tokens.color + ';' +
            'border:1px solid ' + tokens.color + ';' +
            'padding:14px 20px;border-radius:10px;box-shadow:0 4px 20px rgba(0,0,0,0.15);' +
            'font-size:14px;font-weight:500;min-width:250px;max-width:400px;' +
            'display:flex;align-items:center;gap:10px;animation:mtscos-slide-in 0.3s ease;' +
            'cursor:pointer;pointer-events:auto;';
        toast.innerHTML = '<span style="font-size:18px;font-weight:bold;">' + tokens.icon + '</span>' +
                          '<span>' + (message || '') + '</span>';
        container.appendChild(toast);

        let timer = null;
        function remove() {
            if (timer) { clearTimeout(timer); timer = null; }
            toast.style.animation = 'mtscos-slide-out 0.3s ease forwards';
            setTimeout(function () { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 300);
        }
        toast.addEventListener('click', remove);
        timer = setTimeout(remove, duration);
    }

    // ============ 工具函数 ============
    function _getCookie(name) {
        if (typeof document === 'undefined' || !document.cookie) return '';
        const pairs = document.cookie.split(';');
        for (let i = 0; i < pairs.length; i++) {
            const kv = pairs[i].trim().split('=');
            if (kv.length >= 2 && kv[0] === name) {
                return decodeURIComponent(kv.slice(1).join('='));
            }
        }
        return '';
    }

    /** 检测响应格式: 契约格式(有code字段) vs 旧格式(有success字段) */
    function _isContractFormat(data) {
        return data && typeof data === 'object' && typeof data[RESPONSE_FIELDS.CODE] !== 'undefined';
    }

    function _isLegacyFormat(data) {
        return data && typeof data === 'object' &&
            typeof data.code === 'undefined' &&
            typeof data.success !== 'undefined';
    }

    /** 构建query string */
    function _buildQuery(params) {
        if (!params) return '';
        const usp = new URLSearchParams();
        Object.keys(params).forEach(function (k) {
            const v = params[k];
            if (v !== null && v !== undefined && v !== '') usp.append(k, v);
        });
        const s = usp.toString();
        return s ? '?' + s : '';
    }

    /** 注入trace_id到日志上下文(可在控制台追踪) */
    function _logTrace(level, traceId, msg, extra) {
        if (typeof console === 'undefined' || !console[level]) return;
        const prefix = '[MTSCOSApi]';
        if (traceId) {
            console[level](prefix, 'trace_id=' + traceId, msg, extra || '');
        } else {
            console[level](prefix, msg, extra || '');
        }
    }

    // ============ 响应解析器(核心: 8字段对齐) ============
    /**
     * 解析服务器响应为契约格式或旧格式兼容
     * @returns {{ok: boolean, data: *, trace_id: string, payload: object, raw: *}}
     */
    function _parseResponse(payload, httpStatus) {
        // 契约格式: {code, msg, data, trace_id, timestamp, severity, repair_suggestion, design_tokens}
        if (_isContractFormat(payload)) {
            const code = String(payload[RESPONSE_FIELDS.CODE]);
            const traceId = payload[RESPONSE_FIELDS.TRACE_ID] || '';
            // 成功: code === "0"
            if (code === '0' || code === 0) {
                return {
                    ok: true,
                    data: payload[RESPONSE_FIELDS.DATA],
                    trace_id: traceId,
                    msg: payload[RESPONSE_FIELDS.MSG] || '操作成功',
                    timestamp: payload[RESPONSE_FIELDS.TIMESTAMP] || '',
                    raw: payload
                };
            }
            // 失败: code = 异常码
            return {
                ok: false,
                data: null,
                trace_id: traceId,
                msg: payload[RESPONSE_FIELDS.MSG] || '',
                error: new MtscosApiError(code, payload[RESPONSE_FIELDS.MSG], {
                    severity: payload[RESPONSE_FIELDS.SEVERITY],
                    repair_suggestion: payload[RESPONSE_FIELDS.REPAIR_SUGGESTION],
                    design_tokens: payload[RESPONSE_FIELDS.DESIGN_TOKENS],
                    trace_id: traceId,
                    http_status: httpStatus,
                    data: payload[RESPONSE_FIELDS.DATA],
                    timestamp: payload[RESPONSE_FIELDS.TIMESTAMP],
                    route_path: payload.route_path || '',
                    blueprint: payload.blueprint || ''
                }),
                raw: payload
            };
        }

        // 旧格式兼容: {success: true/false, data, message, error}
        if (_isLegacyFormat(payload)) {
            if (payload.success) {
                return {
                    ok: true,
                    data: payload.data,
                    trace_id: payload.trace_id || '',
                    msg: payload.message || '操作成功',
                    timestamp: payload.timestamp || '',
                    raw: payload,
                    legacy: true
                };
            }
            return {
                ok: false,
                data: null,
                trace_id: payload.trace_id || '',
                msg: payload.error || payload.message || '操作失败',
                error: new MtscosApiError('E_SRV_500', payload.error || payload.message, {
                    severity: 'error', http_status: httpStatus, trace_id: payload.trace_id || ''
                }),
                raw: payload,
                legacy: true
            };
        }

        // 非对象(纯文本/数组) → 视为成功,data=原始值
        return {
            ok: httpStatus >= 200 && httpStatus < 300,
            data: payload,
            trace_id: '',
            msg: '',
            raw: payload,
            raw_text: true
        };
    }

    // ============ 主请求函数 ============
    /**
     * 发起HTTP请求(对齐 contract.yaml v1.2.0)
     * @param {string} url - 请求URL
     * @param {object} options - 请求选项
     *   @param {string}  options.method - HTTP方法 GET/POST/PUT/DELETE/PATCH
     *   @param {object}  options.data - 请求体数据(POST/PUT/PATCH)
     *   @param {object}  options.query - URL query参数(GET)
     *   @param {object}  options.headers - 自定义请求头
     *   @param {number}  options.timeout - 超时毫秒(默认30000)
     *   @param {boolean} options.showErrorToast - 失败时是否自动显示Toast(默认true)
     *   @param {boolean} options.showSuccessToast - 成功时是否显示Toast(默认false)
     *   @param {string}  options.successMessage - 自定义成功消息
     *   @param {boolean} options.csrf - 是否注入CSRF Token(默认true)
     *   @param {boolean} options.redirectOnAuth - 鉴权失败时是否跳转登录(默认true)
     *   @param {string}  options.credentials - 凭证模式(默认same-origin)
     * @returns {Promise<*>} 成功返回data, 失败抛出 MtscosApiError
     */
    function request(url, options) {
        options = options || {};
        const method = (options.method || 'GET').toUpperCase();
        const timeout = options.timeout || DEFAULT_TIMEOUT;
        const data = options.data !== undefined ? options.data : null;
        const query = options.query || null;
        const fullUrl = query ? (url + _buildQuery(query)) : url;

        // 构建fetch配置
        const config = {
            method: method,
            credentials: options.credentials || 'same-origin',
            headers: Object.assign({ 'Accept': 'application/json' }, options.headers || {})
        };

        // 注入CSRF Token(委托 mtscos_csrf.js)
        if (options.csrf !== false && typeof MTSCOSCSRF !== 'undefined' && MTSCOSCSRF.inject) {
            MTSCOSCSRF.inject(config, method);
        }

        // 处理请求体
        if (data !== null && ['POST', 'PUT', 'PATCH', 'DELETE'].indexOf(method) !== -1) {
            if (data instanceof FormData) {
                config.body = data;
            } else {
                config.headers['Content-Type'] = config.headers['Content-Type'] || 'application/json';
                config.body = JSON.stringify(data);
            }
        }

        // 超时控制
        const controller = (typeof AbortController !== 'undefined') ? new AbortController() : null;
        if (controller) {
            config.signal = controller.signal;
        }
        const timeoutId = controller ? setTimeout(function () { controller.abort(); }, timeout) : null;

        return fetch(fullUrl, config)
            .then(function (response) {
                const contentType = response.headers.get('content-type') || '';
                if (contentType.indexOf('application/json') !== -1) {
                    return response.json().then(function (json) {
                        return { payload: json, httpStatus: response.status, response: response };
                    });
                }
                // 非JSON响应
                if (!response.ok) {
                    const err = new MtscosApiError('E_SRV_' + response.status, 'HTTP ' + response.status + ': ' + response.statusText, {
                        severity: response.status >= 500 ? 'critical' : 'error',
                        http_status: response.status
                    });
                    throw { error: err, payload: null, httpStatus: response.status, response: response };
                }
                return response.text().then(function (text) {
                    return { payload: text, httpStatus: response.status, response: response };
                });
            })
            .then(function (bundle) {
                const parsed = _parseResponse(bundle.payload, bundle.httpStatus);
                if (parsed.ok) {
                    if (options.showSuccessToast) {
                        showToast(options.successMessage || parsed.msg || '操作成功', 'success');
                    }
                    if (parsed.trace_id) {
                        _logTrace('info', parsed.trace_id, parsed.msg || (method + ' ' + url + ' OK'));
                    }
                    // 返回data; 若是分页响应, data包含 items + pagination
                    return parsed.data;
                }
                // 失败
                const err = parsed.error;
                if (options.showErrorToast !== false) {
                    showToast(err.message + (err.repair_suggestion ? ' (' + err.repair_suggestion + ')' : ''),
                              err.severity || 'error', 5000);
                }
                if (parsed.trace_id) {
                    _logTrace('error', parsed.trace_id, err.code + ' ' + err.message, err.toJSON());
                }
                // 鉴权失败跳转
                if (options.redirectOnAuth !== false && err.isAuthError() && typeof window !== 'undefined') {
                    setTimeout(function () { window.location.href = '/?redirect=' + encodeURIComponent(window.location.pathname); }, 1500);
                }
                throw err;
            })
            .catch(function (e) {
                // AbortError(超时)
                if (e && e.name === 'AbortError') {
                    const err = new MtscosApiError('E_TIMEOUT', '请求超时,请检查网络后重试', {
                        severity: 'error', http_status: 504
                    });
                    if (options.showErrorToast !== false) showToast(err.message, 'error');
                    throw err;
                }
                // 已经是 MtscosApiError, 直接抛出
                if (e && e.name === 'MtscosApiError') throw e;
                // 网络错误
                const err = new MtscosApiError('E_SRV_500', (e && e.message) || '网络错误,请重试', {
                    severity: 'critical', http_status: 0
                });
                if (options.showErrorToast !== false) showToast(err.message, 'critical', 5000);
                _logTrace('error', '', 'Network error: ' + err.message, e);
                throw err;
            })
            .finally(function () {
                if (timeoutId) clearTimeout(timeoutId);
            });
    }

    // ============ 便捷方法 ============
    function get(url, options) {
        const opts = Object.assign({}, options || {}, { method: 'GET' });
        return request(url, opts);
    }

    function post(url, data, options) {
        const opts = Object.assign({}, options || {}, { method: 'POST', data: data });
        return request(url, opts);
    }

    function put(url, data, options) {
        const opts = Object.assign({}, options || {}, { method: 'PUT', data: data });
        return request(url, opts);
    }

    function patch(url, data, options) {
        const opts = Object.assign({}, options || {}, { method: 'PATCH', data: data });
        return request(url, opts);
    }

    function del(url, options) {
        const opts = Object.assign({}, options || {}, { method: 'DELETE' });
        return request(url, opts);
    }

    /**
     * 批量并行请求(对照 Promise.all)
     * @param {Array<{url, method, data, query}>} tasks
     * @returns {Promise<Array>} 全部成功时按顺序返回; 任一失败立即reject
     */
    function all(tasks) {
        const promises = (tasks || []).map(function (t) {
            return request(t.url, t);
        });
        return Promise.all(promises);
    }

    /**
     * 上传文件(FormData)
     * @param {string} url
     * @param {FormData} formData
     * @param {object} options
     */
    function upload(url, formData, options) {
        const opts = Object.assign({}, options || {}, { method: 'POST', data: formData, csrf: true });
        return request(url, opts);
    }

    // ============ 导出 ============
    const MTSCOSApi = {
        VERSION: CONTRACT_VERSION,
        EXCEPTION_CODES: EXCEPTION_CODES,
        SEVERITY_TOKENS: SEVERITY_TOKENS,
        RESPONSE_FIELDS: RESPONSE_FIELDS,
        MtscosApiError: MtscosApiError,
        request: request,
        get: get,
        post: post,
        put: put,
        patch: patch,
        delete: del,
        del: del,  // 别名(避免delete关键字冲突)
        all: all,
        upload: upload,
        showToast: showToast,
        // 查询异常码字典
        lookupException: function (code) { return EXCEPTION_CODES[code] || null; },
        // 查询severity颜色Token
        lookupSeverity: function (severity) { return SEVERITY_TOKENS[severity] || null; }
    };

    // CommonJS + 浏览器全局双导出
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = MTSCOSApi;
    }
    if (typeof global !== 'undefined') {
        global.MTSCOSApi = MTSCOSApi;
    }
    if (typeof window !== 'undefined') {
        window.MTSCOSApi = MTSCOSApi;
    }
})(typeof self !== 'undefined' ? self : this);
