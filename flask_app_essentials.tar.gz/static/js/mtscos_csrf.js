/**
 * ============================================================================
 * MTSCOS CSRF 拦截器 (独立模块)
 * ============================================================================
 * §14 IRON_RULE · STEP_7_EXECUTE · 模块1 后端Blueprint P4
 * flow_id: flow_dev_pages_functions_complete_20260818_001
 * contract_version: 1.2.0 (对照 contract.yaml §3 异常码 E_TOKEN_*)
 *
 * 设计目标:
 *   1. 双源Token获取: meta[name="csrf-token"] (优先) + cookie[csrf_token] (兜底)
 *   2. 仅状态变更方法注入X-CSRF-Token头: POST/PUT/DELETE/PATCH (GET/HEAD/OPTIONS跳过)
 *   3. 异常码处理: E_TOKEN_MISSING自动刷新Token+重试 / E_TOKEN_BREACH强制刷新页面
 *   4. 主动Token刷新: 从 /api/auth/csrf-token 端点拉取新Token并写入meta+cookie
 *   5. 与MTSCOSApi解耦: 可独立使用, 也可被MTSCOSApi.inject调用
 *   6. 兼容旧版apiRequest.js的_getCsrfToken逻辑(向后兼容)
 *
 * 用法:
 *   // 被MTSCOSApi自动调用(推荐)
 *   MTSCOSApi.post('/api/x', {data: 1});  // 自动注入CSRF
 *
 *   // 手动使用
 *   const token = MTSCOSCSRF.getToken();
 *   MTSCOSCSRF.inject(fetchConfig, 'POST');
 *
 *   // 异常处理
 *   if (err.isCSRFError()) MTSCOSCSRF.handleError(err.code);
 * ============================================================================
 */
(function (global) {
    'use strict';

    // ============ 配置常量 ============
    const TOKEN_META_NAME = 'csrf-token';          // <meta name="csrf-token" content="...">
    const TOKEN_HEADER_NAME = 'X-CSRF-Token';      // 发送到后端的请求头
    const TOKEN_COOKIE_NAME = 'csrf_token';        // 兜底Cookie名
    const REFRESH_ENDPOINT = '/api/auth/csrf-token'; // 后端Token刷新端点
    const REFRESH_MAX_RETRY = 1;                  // Token刷新失败重试次数(避免循环)

    // 仅状态变更方法注入Token(GET/HEAD/OPTIONS无副作用,不需要CSRF)
    const STATE_CHANGING_METHODS = new Set(['POST', 'PUT', 'DELETE', 'PATCH']);

    // 异常码对照(与contract.yaml §3一致)
    const CSRF_EXCEPTION_CODES = {
        E_TOKEN_MISSING: 'CSRF Token缺失',
        E_TOKEN_BREACH:  'CSRF Token不匹配'
    };

    // ============ 内部状态 ============
    let _refreshing = false;
    let _refreshPromise = null;
    let _lastToken = '';

    // ============ 工具函数 ============
    function _getCookie(name) {
        if (typeof document === 'undefined' || !document.cookie) return '';
        const pairs = document.cookie.split(';');
        for (let i = 0; i < pairs.length; i++) {
            const kv = pairs[i].trim().split('=');
            if (kv.length >= 2 && kv[0] === name) {
                return decodeURIComponent(kv.slice(1).join('='));
            }
        }
        return '';
    }

    function _setCookie(name, value, maxAgeSec) {
        if (typeof document === 'undefined') return;
        const expires = maxAgeSec
            ? '; max-age=' + maxAgeSec + '; path=/'
            : '; path=/';
        document.cookie = name + '=' + encodeURIComponent(value) + expires + '; SameSite=Lax';
    }

    function _ensureMetaTag() {
        if (typeof document === 'undefined') return null;
        let meta = document.querySelector('meta[name="' + TOKEN_META_NAME + '"]');
        if (!meta) {
            meta = document.createElement('meta');
            meta.setAttribute('name', TOKEN_META_NAME);
            meta.setAttribute('content', '');
            document.head.appendChild(meta);
        }
        return meta;
    }

    // ============ Token 获取/写入 ============
    /**
     * 获取CSRF Token(双源策略)
     * 优先级: meta标签 > cookie
     * @returns {string} Token字符串(无Token返回空串)
     */
    function getToken() {
        // 1. 优先meta标签
        if (typeof document !== 'undefined') {
            const meta = document.querySelector('meta[name="' + TOKEN_META_NAME + '"]');
            if (meta && meta.content) {
                _lastToken = meta.content;
                return meta.content;
            }
        }
        // 2. 兜底Cookie
        const cookieToken = _getCookie(TOKEN_COOKIE_NAME);
        if (cookieToken) {
            _lastToken = cookieToken;
            return cookieToken;
        }
        // 3. 返回空串(后端将返回E_TOKEN_MISSING,触发刷新流程)
        return '';
    }

    /**
     * 写入CSRF Token到meta+cookie双源
     * @param {string} token
     * @param {number} maxAgeSec - Cookie过期秒(默认session,即浏览器关闭)
     */
    function setToken(token, maxAgeSec) {
        if (!token) return;
        _lastToken = token;
        // meta标签
        if (typeof document !== 'undefined') {
            const meta = _ensureMetaTag();
            if (meta) meta.setAttribute('content', token);
        }
        // cookie兜底
        _setCookie(TOKEN_COOKIE_NAME, token, maxAgeSec || 3600);
    }

    // ============ 请求拦截器 ============
    /**
     * 注入CSRF Token到fetch配置(仅状态变更方法)
     * @param {object} config - fetch配置对象(将被就地修改)
     * @param {string} method - HTTP方法
     * @returns {object} 修改后的config
     */
    function inject(config, method) {
        if (!config || !method) return config;
        const upperMethod = String(method).toUpperCase();
        // 仅状态变更方法注入(GET/HEAD/OPTIONS跳过)
        if (!STATE_CHANGING_METHODS.has(upperMethod)) {
            return config;
        }
        const token = getToken();
        if (token) {
            config.headers = config.headers || {};
            // 避免覆盖已显式设置的Token
            if (!config.headers[TOKEN_HEADER_NAME]) {
                config.headers[TOKEN_HEADER_NAME] = token;
            }
        }
        return config;
    }

    // ============ Token 刷新 ============
    /**
     * 从后端刷新CSRF Token
     * 幂等性: 并发刷新只发一次请求,其他调用共享Promise
     * @returns {Promise<string>} 新Token
     */
    function refreshToken() {
        // 并发幂等: 已在刷新中,共享同一Promise
        if (_refreshing && _refreshPromise) {
            return _refreshPromise;
        }
        _refreshing = true;

        _refreshPromise = new Promise(function (resolve, reject) {
            // 使用原生fetch避免循环依赖MTSCOSApi
            const controller = (typeof AbortController !== 'undefined') ? new AbortController() : null;
            const timeoutId = controller ? setTimeout(function () { controller.abort(); }, 5000) : null;

            const config = {
                method: 'GET',
                credentials: 'same-origin',
                headers: { 'Accept': 'application/json' }
            };
            if (controller) config.signal = controller.signal;

            fetch(REFRESH_ENDPOINT, config)
                .then(function (resp) {
                    const ct = resp.headers.get('content-type') || '';
                    if (ct.indexOf('application/json') !== -1) {
                        return resp.json();
                    }
                    return resp.text().then(function () { return null; });
                })
                .then(function (payload) {
                    // 兼容契约格式 {code, msg, data:{token}} 与旧格式 {success, data:{token}}
                    let token = '';
                    if (payload && payload.data && payload.data.token) {
                        token = payload.data.token;
                    } else if (payload && payload.token) {
                        token = payload.token;
                    } else if (typeof payload === 'string' && payload) {
                        token = payload;
                    }
                    if (token) {
                        setToken(token, 3600);
                        resolve(token);
                    } else {
                        reject(new Error('Token刷新失败:响应中无token字段'));
                    }
                })
                .catch(function (e) {
                    reject(e && e.name === 'AbortError'
                        ? new Error('Token刷新超时')
                        : (e || new Error('Token刷新失败')));
                })
                .finally(function () {
                    if (timeoutId) clearTimeout(timeoutId);
                    _refreshing = false;
                    _refreshPromise = null;
                });
        });

        return _refreshPromise;
    }

    // ============ 异常处理 ============
    /**
     * 处理CSRF相关异常码
     * @param {string} errorCode - E_TOKEN_MISSING / E_TOKEN_BREACH
     * @returns {Promise<{retry: boolean, reload: boolean, token: string}>|null}
     *   - E_TOKEN_MISSING: 刷新Token,返回retry=true(可重试原请求)
     *   - E_TOKEN_BREACH: 强制页面刷新(清除旧Token),返回reload=true
     *   - 其他: 返回null(非CSRF错误)
     */
    function handleError(errorCode) {
        if (errorCode === 'E_TOKEN_MISSING') {
            // Token缺失,刷新后可重试
            return refreshToken().then(function (token) {
                return { retry: true, reload: false, token: token };
            }).catch(function () {
                // 刷新失败,强制页面刷新作为兜底
                if (typeof window !== 'undefined') {
                    setTimeout(function () { window.location.reload(); }, 1500);
                }
                return { retry: false, reload: true, token: '' };
            });
        }
        if (errorCode === 'E_TOKEN_BREACH') {
            // Token不匹配(可能是会话过期或CSRF攻击)
            // 清除旧Token,强制页面刷新
            _lastToken = '';
            if (typeof document !== 'undefined') {
                _setCookie(TOKEN_COOKIE_NAME, '', -1); // 立即过期
                const meta = document.querySelector('meta[name="' + TOKEN_META_NAME + '"]');
                if (meta) meta.setAttribute('content', '');
            }
            if (typeof window !== 'undefined') {
                setTimeout(function () { window.location.reload(); }, 1500);
            }
            return Promise.resolve({ retry: false, reload: true, token: '' });
        }
        return null;
    }

    // ============ 自动初始化 ============
    /**
     * 自动从meta/cookie加载Token(若后端模板已渲染了meta标签,则无需手动调用)
     */
    function init() {
        const token = getToken();
        if (token) {
            _lastToken = token;
        }
        return token;
    }

    // ============ 调试/诊断 ============
    function diagnose() {
        const metaTag = (typeof document !== 'undefined')
            ? document.querySelector('meta[name="' + TOKEN_META_NAME + '"]')
            : null;
        return {
            has_meta_tag: !!metaTag,
            meta_content: metaTag ? metaTag.content : '',
            cookie_token: _getCookie(TOKEN_COOKIE_NAME),
            last_token: _lastToken,
            refreshing: _refreshing,
            refresh_endpoint: REFRESH_ENDPOINT,
            state_changing_methods: Array.from(STATE_CHANGING_METHODS)
        };
    }

    // ============ 导出 ============
    const MTSCOSCSRF = {
        TOKEN_META_NAME: TOKEN_META_NAME,
        TOKEN_HEADER_NAME: TOKEN_HEADER_NAME,
        TOKEN_COOKIE_NAME: TOKEN_COOKIE_NAME,
        REFRESH_ENDPOINT: REFRESH_ENDPOINT,
        CSRF_EXCEPTION_CODES: CSRF_EXCEPTION_CODES,
        STATE_CHANGING_METHODS: STATE_CHANGING_METHODS,
        getToken: getToken,
        setToken: setToken,
        inject: inject,
        refreshToken: refreshToken,
        handleError: handleError,
        init: init,
        diagnose: diagnose
    };

    // CommonJS + 浏览器全局双导出
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = MTSCOSCSRF;
    }
    if (typeof global !== 'undefined') {
        global.MTSCOSCSRF = MTSCOSCSRF;
    }
    if (typeof window !== 'undefined') {
        window.MTSCOSCSRF = MTSCOSCSRF;
        // 自动初始化(若meta标签已存在则缓存Token)
        try { init(); } catch (e) { /* 静默失败,首次请求时会再尝试 */ }
    }
})(typeof self !== 'undefined' ? self : this);
