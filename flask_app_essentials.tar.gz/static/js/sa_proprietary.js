/**
 * sa_proprietary.js  —— SA 专有 UI 热插拔控制器
 * 要求：仅当 body.layout-mode-SA_PROPRIETARY 时生效（由 server 端条件注入脚本）。
 * 行为：
 *   · 启动 5s 心跳轮询 /api/hardware/dual-status
 *   · 双钥 true→false：≤10s 内显示锁定遮罩 + body 切 STANDARD + 派发 CustomEvent('sa-layout-updated')
 *   · 双钥 false→true：≤10s 内切换回 SA_PROPRIETARY + 派发 sa-layout-updated
 *   · 连续失败走指数退避：5 → 10 → 20 → 40 → 60（max）
 *   · 成功一次立刻重置 5s
 */
(function () {
  'use strict';
  var BASE_INTERVAL = 5000;   // 5s 心跳
  var MAX_INTERVAL = 60000;   // 60s 退避上限
  var API = '/api/hardware/dual-status';

  function body() { return document.body || document.documentElement; }
  function setLayout(mode) {
    var b = body();
    ['SA_PROPRIETARY', 'STANDARD'].forEach(function (m) {
      b.classList.toggle('layout-mode-' + m, mode === m);
    });
    b.setAttribute('data-layout-mode', mode || 'STANDARD');
  }
  function setLocked(state, reason) {
    var b = body();
    b.classList.toggle('sa-lock', !!state);
    var ov = document.getElementById('sa-lock-overlay');
    if (!ov) {
      ov = document.createElement('div');
      ov.id = 'sa-lock-overlay';
      ov.setAttribute('role', 'dialog');
      ov.setAttribute('aria-modal', 'true');
      ov.innerHTML =
        '<div class="card">' +
          '<div class="title"><span class="pulse"></span>SA 会话已锁定</div>' +
          '<div class="sub" id="sa-lock-reason">请重新插入 VIKEY 加密狗 和 SZU100 专用U盘。</div>' +
        '</div>';
      document.body.appendChild(ov);
    }
    var txt = document.getElementById('sa-lock-reason');
    if (txt) {
      txt.textContent = reason || '请重新插入 VIKEY 加密狗 和 SZU100 专用U盘。';
    }
  }
  function fireLayoutEvent(detail) {
    try {
      var e;
      if (typeof CustomEvent === 'function') {
        e = new CustomEvent('sa-layout-updated', { detail: detail, bubbles: true });
      } else {
        e = document.createEvent('CustomEvent');
        e.initCustomEvent('sa-layout-updated', true, false, detail);
      }
      document.dispatchEvent(e);
      window.dispatchEvent(e);
    } catch (err) { /* 忽略派发异常 */ }
  }
  function currentMode() {
    var b = body();
    if (b.classList.contains('layout-mode-SA_PROPRIETARY')) return 'SA_PROPRIETARY';
    return 'STANDARD';
  }

  var interval = BASE_INTERVAL;
  var timer = null;
  var consecutiveErrors = 0;
  var lastBoth = null;  // null | true | false
  var lockShown = false;
  var lockTimer = null;   // 拔出 → ≤10s 锁定计时器

  /** 注入顶栏三模块占位：如果模板已有，就不覆盖 */
  function ensureTopbarModules() {
    var b = body();
    if (!b.classList.contains('layout-mode-SA_PROPRIETARY')) return;
    var panelId = 'sa-topbar-modules';
    if (document.getElementById(panelId)) return;
    // 为两个 base 尝试挂点：topbar 或 art-header
    var host = document.querySelector('.topbar, .art-header');
    if (!host) return;
    var wrap = document.createElement('div');
    wrap.id = panelId;
    wrap.className = 'sa-topbar-modules';
    wrap.innerHTML =
      '<span class="sa-hw-panel" id="sa-hardware-panel" style="display:none">' +
        '<span class="sa-hw-chip vikey"><span class="sa-lock"></span><i class="fas fa-key" aria-hidden="true"></i> <span id="sa-vikey-txt">VIKEY</span></span>' +
        '<span class="sa-hw-chip szu100"><span class="sa-lock"></span><i class="fas fa-usb" aria-hidden="true"></i> <span id="sa-szu100-txt">SZU100</span></span>' +
      '</span>' +
      '<span class="sa-ef-panel" title="EigenFlux 专家已连接">' +
        '<i class="fas fa-users" aria-hidden="true"></i> EF 专家 <span class="num" id="sa-ef-count">12</span>' +
      '</span>' +
      '<span class="sa-daemon-bar" title="自动化 daemon 健康度">' +
        '<i class="fas fa-server" aria-hidden="true"></i> ' +
        '<span class="track"><span class="fill" id="sa-daemon-fill" style="width:100%"></span></span> ' +
        '<span id="sa-daemon-txt">34/34</span>' +
      '</span>';
    // 优先插入到顶栏左侧(在原内容前或末尾)
    host.prepend ? host.prepend(wrap) : host.insertBefore(wrap, host.firstChild);
  }

  function backoff(err) {
    consecutiveErrors = err ? Math.min(consecutiveErrors + 1, 5) : 0;
    if (err) {
      var mul = Math.pow(2, consecutiveErrors - 1);
      interval = Math.min(BASE_INTERVAL * mul, MAX_INTERVAL);
    } else {
      interval = BASE_INTERVAL;
    }
  }

  function applyTransition(p) {
    var both = !!(p && p.both_authenticated);
    var layout = (p && p.layout_mode) || 'STANDARD';

    // 初始化 lastBoth
    if (lastBoth === null) lastBoth = both;

    // true → false：启动 10s 锁定计时（已被中间件 before_request 阻挡，但前端仍保护）
    if (lastBoth && !both) {
      if (!lockTimer) {
        lockTimer = setTimeout(function () {
          setLayout('STANDARD');
          setLocked(true, (p && p.error) || '双密钥已断开，请重新插入 VIKEY 和 SZU100。');
          lockShown = true;
          fireLayoutEvent({ mode: 'STANDARD', reason: 'dual_key_lost', payload: p });
        }, Math.max(0, 10000 - (interval - BASE_INTERVAL)));
      }
    }
    // false → true：清除锁定
    if (!lastBoth && both) {
      if (lockTimer) { clearTimeout(lockTimer); lockTimer = null; }
      setLocked(false);
      lockShown = false;
      setLayout(layout);
      ensureTopbarModules();
      fireLayoutEvent({ mode: layout, reason: 'dual_key_restored', payload: p });
    }
    // both 为真时，保证顶栏模块可见
    if (both) {
      ensureTopbarModules();
      var panel = document.getElementById('sa-hardware-panel');
      if (panel) panel.style.display = 'inline-flex';
    } else if (lockShown) {
      // 保持锁定 & STANDARD
      setLayout('STANDARD');
    } else {
      setLayout('STANDARD');
    }
    lastBoth = both;
  }

  function tick() {
    var req;
    try { req = new XMLHttpRequest(); } catch (e) { return; }
    req.open('GET', API, true);
    req.timeout = Math.min(interval, 8000);
    req.onreadystatechange = function () {
      if (req.readyState !== 4) return;
      var ok = req.status >= 200 && req.status < 300;
      var p = null;
      try { p = JSON.parse(req.responseText || '{}'); } catch (e) { p = null; ok = false; }
      backoff(!ok);
      if (ok && p) applyTransition(p);
      schedule();
    };
    req.onerror = function () { backoff(true); schedule(); };
    req.ontimeout = function () { backoff(true); schedule(); };
    try { req.send(null); } catch (e) { backoff(true); schedule(); }
  }

  function schedule() {
    if (timer) clearTimeout(timer);
    timer = setTimeout(tick, interval);
  }

  function start() {
    try {
      // 启动前根据当前 body 状态初始化 lastBoth
      lastBoth = body().classList.contains('layout-mode-SA_PROPRIETARY');
      if (lastBoth) ensureTopbarModules();
      schedule();
    } catch (e) { /* 静默失败 */ }
  }

  // 对外暴露 window.SAUIManager
  window.SAUIManager = {
    start: start,
    refresh: tick,
    setLocked: setLocked,
    getState: function () {
      return {
        mode: currentMode(),
        lastBoth: lastBoth,
        lockShown: lockShown,
        interval: interval,
      };
    },
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
