/**
 * ============================================================================
 * MTSCOS 通用组件交互行为 (无依赖纯原生)
 * ============================================================================
 * §14 IRON_RULE · STEP_7_EXECUTE · 模块3 静态CSS/JS P2
 * flow_id: flow_dev_pages_functions_complete_20260818_001
 * contract_version: 1.3.0
 *
 * 依赖: mtscos_design_tokens.css + mtscos_components.css (样式)
 *      可选 mtscos_api.js (异常页对接MtscosApiError, 不强制)
 *
 * 组件清单:
 *   §1 MTSCOSModal        - 模态框(ESC关闭/点击遮罩关闭/动态内容)
 *   §2 MTSCOSConfirm      - 确认对话框(Promise化)
 *   §3 MTSCOSToast        - Toast通知容器(与MTSCOSApi.showToast集成)
 *   §4 MTSCOSExceptionPage- 异常页渲染器(对照contract.yaml §3 8类异常码)
 *   §5 MTSCOSTheme        - 主题切换(light/dark/auto)
 *   §6 MTSCOSForm         - 表单校验工具(基础)
 *   §7 MTSCOSLoader       - 加载态管理(全屏遮罩)
 *
 * 用法:
 *   MTSCOSModal.open({title: '提示', content: '内容', onClose: fn});
 *   MTSCOSConfirm.confirm('确认删除?', '此操作不可逆').then(() => doDelete());
 *   MTSCOSExceptionPage.render({code: 404, title: '页面不存在', traceId: 'abc123'});
 *   MTSCOSTheme.toggle(); // light <-> dark
 * ============================================================================
 */
(function (global) {
    'use strict';

    // ============ §1 MTSCOSModal 模态框 ============
    const MTSCOSModal = (function () {
        let _zIndex = 4000;
        const _openStack = [];

        function _create(options) {
            const mask = document.createElement('div');
            mask.className = 'mtscos-modal-mask';
            mask.style.zIndex = ++_zIndex;
            mask.innerHTML =
                '<div class="mtscos-modal">' +
                  '<div class="mtscos-modal__header">' +
                    '<span class="mtscos-modal__title"></span>' +
                    '<button class="mtscos-modal__close" aria-label="关闭">×</button>' +
                  '</div>' +
                  '<div class="mtscos-modal__body"></div>' +
                  (options.footer === false ? '' :
                    '<div class="mtscos-modal__footer">' +
                      '<button class="mtscos-btn mtscos-btn--secondary mtscos-modal__cancel">取消</button>' +
                      '<button class="mtscos-btn mtscos-btn--primary mtscos-modal__ok">确定</button>' +
                    '</div>') +
                '</div>';
            const titleEl = mask.querySelector('.mtscos-modal__title');
            const bodyEl = mask.querySelector('.mtscos-modal__body');
            const closeBtn = mask.querySelector('.mtscos-modal__close');
            const cancelBtn = mask.querySelector('.mtscos-modal__cancel');
            const okBtn = mask.querySelector('.mtscos-modal__ok');

            titleEl.textContent = options.title || '提示';
            if (typeof options.content === 'string') {
                bodyEl.innerHTML = options.content;
            } else if (options.content instanceof HTMLElement) {
                bodyEl.appendChild(options.content);
            }

            document.body.appendChild(mask);
            // 触发动画
            requestAnimationFrame(function () { mask.classList.add('is-open'); });

            function close() {
                mask.classList.remove('is-open');
                setTimeout(function () {
                    if (mask.parentNode) mask.parentNode.removeChild(mask);
                    const idx = _openStack.indexOf(mask);
                    if (idx !== -1) _openStack.splice(idx, 1);
                    if (typeof options.onClose === 'function') options.onClose();
                }, 300);
            }
            function ok() {
                if (typeof options.onOk === 'function') {
                    const ret = options.onOk(close);
                    if (ret === false) return; // 阻止关闭
                }
                close();
            }

            closeBtn.addEventListener('click', close);
            if (cancelBtn) cancelBtn.addEventListener('click', close);
            if (okBtn) okBtn.addEventListener('click', ok);
            if (options.maskClosable !== false) {
                mask.addEventListener('click', function (e) { if (e.target === mask) close(); });
            }
            mask.addEventListener('keydown', function (e) {
                if (e.key === 'Escape') close();
            });
            // 焦点
            mask.tabIndex = -1;
            mask.focus();

            _openStack.push(mask);
            return { close: close, mask: mask };
        }

        return {
            open: _create,
            alert: function (content, title) {
                return new Promise(function (resolve) {
                    _create({
                        title: title || '提示',
                        content: content,
                        footer: false,
                        onClose: resolve,
                        onOk: function () {}
                    });
                    // alert模式只有确定按钮
                });
            },
            closeAll: function () {
                while (_openStack.length) {
                    const m = _openStack.pop();
                    if (m && m.parentNode) m.parentNode.removeChild(m);
                }
            }
        };
    })();

    // ============ §2 MTSCOSConfirm 确认对话框(Promise化) ============
    const MTSCOSConfirm = (function () {
        function confirm(message, title, options) {
            options = options || {};
            return new Promise(function (resolve) {
                const modal = MTSCOSModal.open({
                    title: title || '确认',
                    content: '<p style="padding:8px 0;font-size:14px;color:var(--el-text-color-regular);">' +
                              _escapeHtml(String(message || '')) + '</p>',
                    okText: options.okText || '确定',
                    cancelText: options.cancelText || '取消',
                    onOk: function (close) {
                        close();
                        resolve(true);
                    },
                    onClose: function () {
                        resolve(false);
                    }
                });
                // 自定义按钮文案
                const okBtn = modal.mask.querySelector('.mtscos-modal__ok');
                const cancelBtn = modal.mask.querySelector('.mtscos-modal__cancel');
                if (okBtn && options.okText) okBtn.textContent = options.okText;
                if (cancelBtn && options.cancelText) cancelBtn.textContent = options.cancelText;
                if (options.okType === 'danger') {
                    okBtn.classList.remove('mtscos-btn--primary');
                    okBtn.classList.add('mtscos-btn--danger');
                }
            });
        }
        return { confirm: confirm };
    })();

    // ============ §3 MTSCOSToast (与MTSCOSApi.showToast集成, 可独立使用) ============
    const MTSCOSToast = (function () {
        let _container = null;
        function _ensureContainer() {
            if (_container) return _container;
            _container = document.createElement('div');
            _container.id = 'mtscos-toast-container';
            _container.className = 'mtscos-toast-container';
            document.body.appendChild(_container);
            return _container;
        }
        function show(message, severity, duration) {
            severity = severity || 'info';
            duration = duration || 3000;
            const container = _ensureContainer();
            const token = _getSeverityToken(severity);
            const toast = document.createElement('div');
            toast.style.cssText =
                'background:' + token.bg + ';' +
                'color:' + token.color + ';' +
                'border:1px solid ' + token.color + ';' +
                'padding:14px 20px;border-radius:6px;' +
                'box-shadow:0 4px 20px rgba(0,0,0,0.15);' +
                'font-size:14px;font-weight:500;min-width:250px;max-width:400px;' +
                'display:flex;align-items:center;gap:10px;' +
                'animation:mtscos-slide-in 0.3s ease;cursor:pointer;pointer-events:auto;';
            toast.innerHTML = '<span style="font-size:18px;font-weight:bold;">' + token.icon + '</span>' +
                              '<span>' + _escapeHtml(String(message || '')) + '</span>';
            container.appendChild(toast);
            let timer = null;
            function remove() {
                if (timer) { clearTimeout(timer); timer = null; }
                toast.style.animation = 'mtscos-slide-out 0.3s ease forwards';
                setTimeout(function () { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 300);
            }
            toast.addEventListener('click', remove);
            timer = setTimeout(remove, duration);
            return { close: remove };
        }
        function _getSeverityToken(severity) {
            const map = {
                info:     { color: 'var(--mtscos-severity-info-color)',     bg: 'var(--mtscos-severity-info-bg)',     icon: 'ℹ' },
                warning:  { color: 'var(--mtscos-severity-warning-color)',  bg: 'var(--mtscos-severity-warning-bg)',  icon: '⚠' },
                error:    { color: 'var(--mtscos-severity-error-color)',    bg: 'var(--mtscos-severity-error-bg)',    icon: '✕' },
                critical: { color: 'var(--mtscos-severity-critical-color)', bg: 'var(--mtscos-severity-critical-bg)', icon: '✕' },
                success:  { color: 'var(--mtscos-severity-success-color)', bg: 'var(--mtscos-severity-success-bg)', icon: '✓' }
            };
            return map[severity] || map.info;
        }
        return {
            show: show,
            info: function (m, d) { return show(m, 'info', d); },
            success: function (m, d) { return show(m, 'success', d); },
            warning: function (m, d) { return show(m, 'warning', d); },
            error: function (m, d) { return show(m, 'error', d); },
            critical: function (m, d) { return show(m, 'critical', d); }
        };
    })();

    // ============ §4 MTSCOSExceptionPage 异常页渲染器(对照contract.yaml §3) ============
    const MTSCOSExceptionPage = (function () {
        // 异常码字典(对照contract.yaml §3 + mtscos_api.js EXCEPTION_CODES)
        const EXCEPTION_MAP = {
            401: { code: 'E_AUTH_401', title: '未登录或登录已过期', desc: '请重新登录后访问该页面', repair: '点击下方按钮跳转登录' },
            403: { code: 'E_AUTH_403', title: '权限不足,禁止访问', desc: '您没有访问此页面的权限', repair: '请联系管理员申请权限' },
            404: { code: 'E_ROUTE_404', title: '页面/接口不存在', desc: '您访问的内容可能已被移除或URL错误', repair: '检查URL或返回首页' },
            500: { code: 'E_SRV_500', title: '服务器内部错误', desc: '服务器处理请求时发生异常', repair: '请稍后重试,或联系运维' },
            502: { code: 'E_SRV_502', title: '上游网关错误', desc: '上游服务暂时不可用', repair: '请稍后重试' },
            503: { code: 'E_MAINTENANCE', title: '系统维护中', desc: '系统正在进行维护,请稍后访问', repair: '维护完成后自动恢复' },
            504: { code: 'E_SRV_504', title: '网关超时', desc: '请求处理超时,服务器未及时响应', repair: '请优化查询或稍后重试' }
        };

        function render(opts) {
            opts = opts || {};
            const status = Number(opts.code || opts.status || 500);
            const info = EXCEPTION_MAP[status] || EXCEPTION_MAP[500];
            const container = (typeof opts.container === 'string')
                ? document.querySelector(opts.container)
                : (opts.container || document.body);
            if (!container) return;

            // 优先使用自定义文案, 否则用字典默认
            const title = opts.title || info.title;
            const description = opts.description || opts.desc || info.desc;
            const repair = opts.repair || opts.repair_suggestion || info.repair;
            const traceId = opts.trace_id || opts.traceId || '';

            const html =
                '<div class="mtscos-exception mtscos-exception--' + status + '">' +
                  '<div class="mtscos-exception__code">' + status + '</div>' +
                  '<div class="mtscos-exception__title">' + _escapeHtml(title) + '</div>' +
                  '<div class="mtscos-exception__description">' + _escapeHtml(description) + '</div>' +
                  (repair ? '<div class="mtscos-exception__repair">💡 ' + _escapeHtml(repair) + '</div>' : '') +
                  '<div class="mtscos-exception__actions">' +
                    (opts.actions || _defaultActions(status)) +
                  '</div>' +
                  (traceId ? '<div class="mtscos-exception__trace_id">trace_id: ' + _escapeHtml(traceId) + '</div>' : '') +
                '</div>';
            container.innerHTML = html;
            return container;
        }

        function _defaultActions(status) {
            if (status === 401) {
                return '<a class="mtscos-btn mtscos-btn--primary mtscos-btn--round" href="/?redirect=' +
                       encodeURIComponent(location.pathname) + '">重新登录</a>';
            }
            return '<a class="mtscos-btn mtscos-btn--secondary mtscos-btn--round" href="/">返回首页</a>' +
                   '<button class="mtscos-btn mtscos-btn--primary mtscos-btn--round" onclick="history.back()">返回上页</button>';
        }

        /**
         * 从 MtscosApiError 自动渲染异常页
         * @param {MtscosApiError} err
         * @param {object} container
         */
        function renderFromError(err, container) {
            if (!err || !err.http_status) return;
            return render({
                code: err.http_status,
                title: err.message,
                description: '异常码: ' + err.code + (err.blueprint ? ' (Blueprint: ' + err.blueprint + ')' : ''),
                repair: err.repair_suggestion,
                trace_id: err.trace_id,
                container: container
            });
        }

        return {
            EXCEPTION_MAP: EXCEPTION_MAP,
            render: render,
            renderFromError: renderFromError
        };
    })();

    // ============ §5 MTSCOSTheme 主题切换 ============
    const MTSCOSTheme = (function () {
        const STORAGE_KEY = 'mtscos-theme';
        const VALID_THEMES = ['light', 'dark', 'auto'];

        function get() {
            const stored = (typeof localStorage !== 'undefined') ? localStorage.getItem(STORAGE_KEY) : null;
            return VALID_THEMES.indexOf(stored) !== -1 ? stored : 'auto';
        }

        function set(theme) {
            if (VALID_THEMES.indexOf(theme) === -1) theme = 'auto';
            if (typeof localStorage !== 'undefined') localStorage.setItem(STORAGE_KEY, theme);
            _apply(theme);
        }

        function _apply(theme) {
            const actual = (theme === 'auto') ? _detectSystem() : theme;
            if (actual === 'dark') {
                document.documentElement.setAttribute('data-theme', 'dark');
            } else {
                document.documentElement.setAttribute('data-theme', 'light');
            }
            // 触发事件
            document.dispatchEvent(new CustomEvent('mtscos:theme-change', { detail: { theme: theme, actual: actual } }));
        }

        function _detectSystem() {
            return (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light';
        }

        function toggle() {
            const current = get();
            const next = (current === 'dark') ? 'light' : 'dark';
            set(next);
            return next;
        }

        function init() {
            const theme = get();
            _apply(theme);
            // 监听系统主题变化(仅auto模式生效)
            if (window.matchMedia) {
                window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function () {
                    if (get() === 'auto') _apply('auto');
                });
            }
        }

        return {
            get: get,
            set: set,
            toggle: toggle,
            init: init,
            VALID_THEMES: VALID_THEMES
        };
    })();

    // ============ §6 MTSCOSForm 表单校验工具 ============
    const MTSCOSForm = (function () {
        /**
         * 校验表单
         * @param {HTMLFormElement} form
         * @param {object} rules - {fieldName: [{required: bool, message: string, pattern: RegExp, min: num, max: num}]}
         * @returns {{valid: boolean, errors: object}}
         */
        function validate(form, rules) {
            const errors = {};
            let valid = true;
            Object.keys(rules || {}).forEach(function (name) {
                const field = form.querySelector('[name="' + name + '"]');
                if (!field) return;
                const value = (field.value || '').toString().trim();
                const ruleList = rules[name];
                for (let i = 0; i < ruleList.length; i++) {
                    const r = ruleList[i];
                    if (r.required && !value) {
                        errors[name] = r.message || '此项必填';
                        valid = false;
                        break;
                    }
                    if (r.pattern && value && !r.pattern.test(value)) {
                        errors[name] = r.message || '格式不正确';
                        valid = false;
                        break;
                    }
                    if (r.min !== undefined && value.length < r.min) {
                        errors[name] = r.message || '至少' + r.min + '个字符';
                        valid = false;
                        break;
                    }
                    if (r.max !== undefined && value.length > r.max) {
                        errors[name] = r.message || '最多' + r.max + '个字符';
                        valid = false;
                        break;
                    }
                }
                // 渲染错误到对应form-item
                const formItem = field.closest('.mtscos-form-item');
                if (formItem) {
                    formItem.classList.toggle('is-error', !!errors[name]);
                    let errEl = formItem.querySelector('.mtscos-form-item__error');
                    if (!errEl) {
                        errEl = document.createElement('div');
                        errEl.className = 'mtscos-form-item__error';
                        formItem.appendChild(errEl);
                    }
                    errEl.textContent = errors[name] || '';
                }
            });
            return { valid: valid, errors: errors };
        }

        return { validate: validate };
    })();

    // ============ §7 MTSCOSLoader 加载态管理 ============
    const MTSCOSLoader = (function () {
        let _mask = null;

        function show(text) {
            hide();
            _mask = document.createElement('div');
            _mask.className = 'mtscos-loading-mask';
            _mask.style.cssText = 'position:fixed;inset:0;background:rgba(255,255,255,0.6);' +
                                   'display:flex;align-items:center;justify-content:center;' +
                                   'z-index:9998;backdrop-filter:blur(2px);';
            _mask.innerHTML =
                '<div style="display:flex;flex-direction:column;align-items:center;gap:12px;">' +
                  '<div class="mtscos-spinner mtscos-spinner--large"></div>' +
                  '<div style="font-size:14px;color:var(--el-text-color-regular);">' +
                    _escapeHtml(text || '加载中...') + '</div>' +
                '</div>';
            document.body.appendChild(_mask);
        }

        function hide() {
            if (_mask && _mask.parentNode) {
                _mask.parentNode.removeChild(_mask);
                _mask = null;
            }
        }

        return { show: show, hide: hide };
    })();

    // ============ 工具函数 ============
    function _escapeHtml(str) {
        if (str == null) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    // ============ 自动初始化 ============
    function _autoInit() {
        // 主题初始化
        try { MTSCOSTheme.init(); } catch (e) {}
        // 全局ESC关闭modal(已在MTSCOSModal中处理)
    }
    if (typeof document !== 'undefined') {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', _autoInit);
        } else {
            _autoInit();
        }
    }

    // ============ 导出 ============
    const MTSCOSComponents = {
        Modal: MTSCOSModal,
        Confirm: MTSCOSConfirm,
        Toast: MTSCOSToast,
        ExceptionPage: MTSCOSExceptionPage,
        Theme: MTSCOSTheme,
        Form: MTSCOSForm,
        Loader: MTSCOSLoader
    };

    if (typeof module !== 'undefined' && module.exports) {
        module.exports = MTSCOSComponents;
    }
    if (typeof global !== 'undefined') global.MTSCOSComponents = MTSCOSComponents;
    if (typeof window !== 'undefined') {
        window.MTSCOSComponents = MTSCOSComponents;
        // 兼容独立访问
        window.MTSCOSModal = MTSCOSModal;
        window.MTSCOSConfirm = MTSCOSConfirm;
        window.MTSCOSToast = MTSCOSToast;
        window.MTSCOSExceptionPage = MTSCOSExceptionPage;
        window.MTSCOSTheme = MTSCOSTheme;
        window.MTSCOSForm = MTSCOSForm;
        window.MTSCOSLoader = MTSCOSLoader;
    }
})(typeof self !== 'undefined' ? self : this);
