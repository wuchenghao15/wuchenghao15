[前端静态资源]
- css/ : 样式表（含 mtscos_design_tokens.css §11 仙女座前端美化层）
- js/ : Vue 组件 + 业务 JS
- images/ : 图片资源
- images/andromeda_stars/ : 25 颗仙女座恒星图标
